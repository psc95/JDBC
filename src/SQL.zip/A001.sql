select ename, sal*12+NVL(COMM,0) as "annual income" from emp
/
