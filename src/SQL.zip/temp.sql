select ename,sal from emp
/
select empno,ename,sal from emp
/
